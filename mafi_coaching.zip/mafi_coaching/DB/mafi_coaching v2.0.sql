-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2020 at 01:16 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mafi_coaching`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(101, 'yeamin', 'yeaminrabbi308@gmail.com', 'yeaminrabbi204'),
(102, 'kanak', 'ikanak@gmail.com', 'MAFIkanak@79#');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(10) NOT NULL,
  `title` varchar(111) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `faculty` varchar(222) NOT NULL DEFAULT 'Benzir',
  `seat` int(11) NOT NULL DEFAULT 25
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `date`, `status`, `faculty`, `seat`) VALUES
(1, 'PHP', '2020-01-31', 1, 'Benzir', 19),
(2, 'Laravel', '2020-01-28', 0, 'Benzir', 24),
(3, 'JAVA', '2020-01-25', 1, 'Benzir', 23),
(4, 'DLD', '2020-01-26', 1, 'Benzir', 25),
(5, 'C Program', '2020-01-26', 1, 'Benzir', 25),
(15, 'DD 2', '2020-02-29', 1, 'Mofiz Sir', 140),
(199, 'Conputer Course', '2020-01-16', 1, 'Imama Sir', 25),
(248, 'Jango', '2020-02-03', 1, 'Benzir', 538),
(566, 'Accounting', '2020-01-13', 1, 'Benzir', 24),
(1515, 'DLD 2', '2020-02-13', 1, 'Benzir', 39),
(5555, 'CT', '2020-02-21', 1, 'Benzir Ahmed', 1),
(10122, 'GAME', '2020-01-01', 1, 'Benzir Mohammad', 24);

-- --------------------------------------------------------

--
-- Table structure for table `table_course`
--

CREATE TABLE `table_course` (
  `id` int(100) NOT NULL,
  `unique_code` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `student_id` int(201) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `course_id` int(11) NOT NULL,
  `activation` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_course`
--

INSERT INTO `table_course` (`id`, `unique_code`, `course_name`, `student_id`, `student_name`, `course_id`, `activation`) VALUES
(1001, '11111', 'kk', 2, 'hh', 12, 1),
(1002, '1004-DLD 2', 'DLD 2', 1004, 'yeamin248', 1515, 0),
(1003, '1004-PHP', 'PHP', 1004, 'yeamin248', 1, 0),
(1004, '1003-JAVA', 'JAVA', 1003, 'tanha', 3, 0),
(1005, '1003-PHP', 'PHP', 1003, 'tanha', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(255) NOT NULL DEFAULT '1234',
  `active` int(11) NOT NULL DEFAULT 0,
  `contact` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `active`, `contact`) VALUES
(1001, 'tushar', 'tushar@gmail.com', '248', 1, '01768002727'),
(1002, 'abid', 'abid@gmail.com', '1111234', 1, '01119'),
(1003, 'tanha', 'tanha@gmail.com', '256', 1, '9973'),
(1004, 'yeamin248', 'yeaminrabbi308@gmail.com', '248', 1, '01950245204'),
(1005, 'Tanzim Tamanna Ritu', 'ttamanna249@gmail.com', 'apnipocha', 1, '01768002727'),
(1006, 'Tanzim Tamanna Ritu', 'ttamanna249@gmail.com', 'apnipocha', 1, '01768002727'),
(1007, 'titu', 'yeaminrabbi308@gmail.com', 'apnipocha', 1, '01768002727');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_course`
--
ALTER TABLE `table_course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10123;

--
-- AUTO_INCREMENT for table `table_course`
--
ALTER TABLE `table_course`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1006;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1008;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
