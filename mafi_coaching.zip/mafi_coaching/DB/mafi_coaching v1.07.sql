-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2020 at 05:08 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mafi_coaching`
--

-- --------------------------------------------------------

--
-- Table structure for table `course_confirmation`
--

CREATE TABLE `course_confirmation` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `course_student`
--

CREATE TABLE `course_student` (
  `c_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course_table`
--

CREATE TABLE `course_table` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `faculty` varchar(25) NOT NULL,
  `fee` int(255) NOT NULL DEFAULT 3000,
  `time` varchar(20) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_table`
--

INSERT INTO `course_table` (`id`, `name`, `faculty`, `fee`, `time`, `date`) VALUES
(101, 'DLD', 'Benzir', 3000, '9-11pm', '2020-01-31'),
(102, 'Game', 'Md. Benzir', 8000, '9-11pm', '2020-01-31'),
(103, 'Java', 'Md. Shakkhar', 18000, '9-11pm', '2020-01-30'),
(104, 'CN LAb', 'Md. Benzir', 82000, '9-11pm', '2020-01-28'),
(105, 'CA', 'Md. Yousuf', 28000, '10-11pm', '2020-01-31'),
(120, 'PHP', 'Benzir', 3000, '9-11pm', '2020-01-31'),
(122, 'PHP', 'Benzir', 3000, '9-11pm', '2020-01-12'),
(193, 'CN', 'Md. Benzir', 8000, '9-11pm', '2020-01-29'),
(1210, 'PHP', 'Benzir', 3000, '9-11pm', '2020-01-21'),
(12031, 'PHP', 'Benzir', 3000, '9-11pm', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(10) NOT NULL,
  `title` varchar(111) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `faculty` varchar(222) NOT NULL DEFAULT 'Benzir',
  `seat` int(11) NOT NULL DEFAULT 25,
  `booking` int(11) NOT NULL DEFAULT 15,
  `confirmed` int(11) NOT NULL DEFAULT 5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `date`, `status`, `faculty`, `seat`, `booking`, `confirmed`) VALUES
(1, 'PHP', '2020-01-31', 1, 'Benzir', 25, 15, 5),
(2, 'Laravel', '2020-01-28', 0, 'Benzir', 24, 15, 5),
(3, 'JAVA', '2020-01-25', 1, 'Benzir', 24, 15, 5),
(4, 'DLD', '2020-01-26', 1, 'Benzir', 25, 15, 5),
(5, 'C Program', '2020-01-26', 1, 'Benzir', 25, 15, 5),
(191, 'Python ', '2020-02-19', 1, 'Benzir', 25, 15, 5),
(199, 'Conputer Course', '2020-01-16', 1, 'Imama Sir', 25, 15, 5),
(501, 'Python 2 ', '2020-02-03', 1, 'Benzir', 145, 15, 5),
(511, 'DLD ', '2020-02-20', 1, 'MD. Benzir', 45, 15, 5),
(551, 'Python ', '2020-02-10', 1, 'Benzir', 25, 15, 5),
(566, 'Accounting', '2020-01-13', 1, 'Benzir', 25, 15, 5),
(10122, 'GAME', '2020-01-01', 1, 'Benzir Mohammad', 25, 15, 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(255) NOT NULL DEFAULT '1234',
  `active` int(11) NOT NULL DEFAULT 0,
  `contact` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `active`, `contact`) VALUES
(1001, 'tushar', 'tushar@gmail.com', '248', 1, '01768002727'),
(1002, 'abid', 'abid@gmail.com', '1111234', 1, '01119'),
(1003, 'tanha', 'tanha@gmail.com', '256', 1, '9973'),
(1009, 'tanha', 'tahkk2@gmail.com', 'ooo', 1, '000'),
(1010, 'Arif Mahmud', 'arif@gmail.com', '999', 1, '019999999'),
(1012, 'Arif Mahmud', 'arif@gmail.com', '999', 1, '019999999'),
(1013, 'Arif Mahmud', 'arif@gmail.com', '999', 1, '019999999'),
(1014, 'Arif Mahmud', 'arif@gmail.com', '999', 1, '019999999'),
(1015, 'Arif Mahmud', 'arif@gmail.com', '999', 1, '019999999'),
(1016, 'tanha', 'tushar@gmail.com', 'jo', 1, '11'),
(1017, 'tanha', 'tushar@gmail.com', 'jo', 1, '11'),
(1018, 'Yousuf', 'yousuf@gmail.com', 'pass', 1, '019922222'),
(1019, 'Yousuf', 'yousuf@gmail.com', 'pass', 1, '019922222'),
(1020, 'asif', 'asif@gmail.com', '11', 1, '01999'),
(1021, 'ishrak', 'ishrak@gmail.com', '00', 1, '000999');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course_table`
--
ALTER TABLE `course_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10123;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1022;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
