<?php require_once('includes/header.php') ?>
	<!--Navigation Bar-->
	<?php require_once('includes/nav.php') ?>

	<div class="cointainer">
		<div class="row">
			<div class="col-lg-5 m-auto">
				<div class="card bg-light mt-5 py-2">
					<div class="card-title">
						<h2 class="text-center mt-2"> Registration Form </h2>
						<hr>
					</div>
					<div class="card-body">
					
						<form action="registration2.php" method="POST">
							<input type="text" name="USERNAME" placeholder=" User Name " class="form-control py-2 mb-2" required>

							<input type="email" name="email" placeholder=" Email " class="form-control py-2 mb-2" required>

							<input type="text" name="contact" placeholder=" Contact No. " class="form-control py-2 mb-2" required>
							
							<input type="text" name="pass" placeholder=" Password " class="form-control py-2 mb-2" required>
							
							<input type="text" name="cpass" placeholder=" Confirm Pasword " class="form-control py-2 mb-2" required>
							
							

							<input type="submit" name="submit" value="submit" class="btn btn-success float-right" >
							
						</form>


					</div>
					
				</div>
				
			</div>
			
		</div>
		
	</div>




<?php require_once('includes/footer.php') ?>




