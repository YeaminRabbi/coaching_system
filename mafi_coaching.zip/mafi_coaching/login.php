<?php require_once('includes/header.php') ?>

	<!--Navigation Bar-->
	<?php require_once('includes/nav.php') ?>

	<div class="cointainer">
		<div class="row">
			<div class="col-lg-4 m-auto">
				<div class="card bg-light mt-5 py-2">
					<div class="card-title">
						<h2 class="text-center mt-2"> Login </h2>
						<hr>
					</div>
					
					<form action="" method="POST">
						<div class="card-body">
						<input type="text" name="UserName" placeholder=" UserName " class="form-control py-2 mb-2" required>
						<input type="text" name="UPass" placeholder=" Password " class="form-control py-2 mb-2" required>
						<button class="btn btn-dark float-right"> Login </button>
					</div>
					</form>
					
					<div class="card-footer">
						<input type="checkbox" name="remember"> <span> Remember Me </span>
						<a href="recover.php" class="float-right"> Forget Password </a>
						
					</div>

					
				</div>
				
			</div>
			
		</div>
		
	</div>

<?php require_once('includes/footer.php') ?>


<?php

$username="";
$password="";

if( isset($_POST['UserName']) ){
	$username=$_POST['UserName'];
}

if( isset($_POST['UPass']) ){
	$password=$_POST['UPass'];
}


///database connection
try{
	$conn = new PDO("mysql:host=localhost;dbname=mafi_coaching;","root","");
}
catch(PDOException $err){
	echo "<script>window.alert('db connection error');</script>";
		echo "<script>location.assign('login.php');</script>";
}


$userprofile=0;
$adminprofile=0;

########user part######
$sqlquery="SELECT * FROM user WHERE name='$username' AND password='$password'";

$object=$conn->query($sqlquery);
if($object->rowCount()==1){
	
	$userprofile=1;
}
else 
{
	$userprofile=-1;
}

session_start();

if($userprofile==1)
{
	$_SESSION['username'] = $username;
	$_SESSION['login']=1;


	$result="";
					$con=mysqli_connect("localhost","root","","mafi_coaching");

				if (mysqli_connect_errno()) {
				  echo "Failed to connect to MySQL: " . mysqli_connect_error();
				  exit();
				}

				$sql = "SELECT * FROM user where name='$username'";
				$result = mysqli_query($con,$sql);

				// Numeric array
				$row = mysqli_fetch_array($result, MYSQLI_NUM);
				
				// Free result set
				mysqli_free_result($result);

				mysqli_close($con);



	$_SESSION['id'] =$row[0];
	$_SESSION['email']=$row[2];
	#$_SESSION['password']=$row[3];


	
#echo "<script>window.alert('Login Successful');</script>";
#echo "Login suucessful";

	echo "<script>location.assign('userpage.php');</script>";
}

############admin part###########

$sqlquery="SELECT * FROM admin WHERE name='$username' AND password='$password'";
$object=$conn->query($sqlquery);
if($object->rowCount()==1){
	
	$adminprofile=1;
}
else 
{
	$adminprofile=-1;
}


if($adminprofile==1)
{
	$_SESSION['username'] = $username;
	$_SESSION['login']=1;


	$result="";
				$con=mysqli_connect("localhost","root","","mafi_coaching");

				if (mysqli_connect_errno()) {
				  echo "Failed to connect to MySQL: " . mysqli_connect_error();
				  exit();
				}

				$sql = "SELECT * FROM admin where name='$username'";
				$result = mysqli_query($con,$sql);

				// Numeric array
				$row = mysqli_fetch_array($result, MYSQLI_NUM);
				
				// Free result set
				mysqli_free_result($result);

				mysqli_close($con);



	$_SESSION['id'] =$row[0];
	$_SESSION['email']=$row[2];
	#$_SESSION['password']=$row[3];


	
#echo "<script>window.alert('Login Successful');</script>";
#echo "Login suucessful";

	echo "<script>location.assign('admin.php');</script>";
}

?>
	