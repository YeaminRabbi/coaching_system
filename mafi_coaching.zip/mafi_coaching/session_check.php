
<?php
session_start();

if(isset($_SESSION['login']))
{
	
		
		$done=1;
	
}


else
{
	echo "<script>location.assign('login.php');</script>";
}

?>
