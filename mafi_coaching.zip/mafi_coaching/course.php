

<?php require_once('dbconfig.php') ?>
<?php require_once('session_check.php') ?>
<?php require_once('includes/header.php') ?>

	<!--Navigation Bar-->
	<?php require_once('includes/user_nav.php') ?>


		<div class="container" style="padding-top: 20px;">
		<div style="padding-left: 41%">
			<h3>Course Table</h3>

			
		</div>
		
			

		<table class="table">
    	<thead>
	      <tr>
	        <th>Cours ID</th>
	        <th>Course Name</th>
	        <th>Faculty</th>
	        <th>Date</th>
	        

	        
	        
	      </tr>

	      <?php


	      	$student_id=$_SESSION['id'];


	      		$sql="SELECT t1.course_id, t1.course_name,t2.faculty,t2.date from table_course as t1 JOIN events as t2 on t1.course_id = t2.id   where t1.student_id= '$student_id' and t1.activation=1";

	      	


			      $result = $db-> query($sql);
			      if($result-> num_rows >0)
			      {


			        while ($row = $result-> fetch_assoc()) {
			            echo "<tr>
			            <td>". $row["course_id"] ."</td>
			            <td>". $row["course_name"] ."</td>
			            <td>". $row["faculty"] ."</td>
			            <td>". $row["date"] ."</td>
			            
			            
			            </tr>";         
			          }
			            echo "</table>";
			      }

			      
			    



	      ?>






    </thead>



	</div>





<?php require_once('includes/footer.php') ?>

