<?php require_once('dbconfig.php') ?>
<?php require_once('session_check.php') ?>
<?php require_once('includes/header.php') ?>
	<!--Navigation Bar-->
	<?php require_once('includes/admin_nav.php') ?>


			<div class="container" style="padding-top: 20px;">
					<div style="padding-left: 41%">
						<h3>Students Details</h3>

						
					</div>
					
						

					<table class="table">
			    	<thead>
				      <tr>
				        <th>Student ID</th>
				        <th>Student Name</th>
				        <th>Email</th>
				        <th>Contact NO.</th>
				     </tr>

				      <?php

							$sql="SELECT id,name,email,contact from user where active=1";

				      	


						      $result = $db-> query($sql);
						      if($result-> num_rows >0)
						      {


						        while ($row = $result-> fetch_assoc()) {
						            echo "<tr>
						            <td>". $row["id"] ."</td>
						            <td>". $row["name"] ."</td>
						            <td>". $row["email"] ."</td>
						            <td>". $row["contact"] ."</td>
						            
						            
						            </tr>";         
						          }
						            echo "</table>";
						      }

						?>
			</thead>

	</div>






<?php require_once('includes/footer.php') ?>