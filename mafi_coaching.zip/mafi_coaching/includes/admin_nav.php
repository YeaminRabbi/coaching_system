<nav class="navbar navbar-expand-sm navbar-light bg-light">
		<div class="container">
			<a href="admin.php" class="navbar navbar-brand"><h3> MAFI Coaching </h3></a>
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a href="admin.php" class="nav-link"></a>
				</li>
				<li class="nav-item">
					<a href="#" class="nav-link"></a>
				</li>
				
			</ul>


			<ul class="nav navbar-nav navbar-right">

				
				<?php

					$gap="&nbsp";
				  if(isset($_SESSION['login'])) { ?>
					<li><a href="#"><?php  echo "ADMIN: "; echo  $_SESSION['username']; ?></a></li>	
					<li><a href="#"><?php  echo $gap.$gap.$gap; ?></a></li>	

					<li><a href="#"><?php  echo "ID: "; echo  $_SESSION['id']; ?></a></li>	
				<?php } ?>

				<li class="active" style="padding-left: 20px;"><a href="logout.php"> <button class="btn btn-danger">Logout</button></a></li>
				
				
				
			</ul>

				
		</div>
		
	</nav>


	<div class="cointainer">
		<div class="row">
			<div class="col">
				<h3 class="text-center"> Admin Panel</h3>
				
			</div>
			
		</div>
		
	</div>

	<nav class="navbar navbar-expand navbar-dark bg-dark ">
						<div class="container ">
							
							<ul class="navbar-nav mr-auto">
								<li class="nav-item">
									<a href="admin.php" class="nav-link">Home</a>
								</li>
								<li class="nav-item">
									<a href="add_course.php" class="nav-link">Add Course</a>
								</li>
								<li class="nav-item">
									<a href="course_registration.php" class="nav-link">Course Registration</a>
								</li>
								<li class="nav-item">
									<a href="student_details.php" class="nav-link">Student Details</a>
								</li>

								
							</ul>
						</div>
					
	</nav>
