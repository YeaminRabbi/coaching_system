<nav class="navbar navbar-expand-sm navbar-light bg-light">
		<div class="container">
			<a href="index.php" class="navbar navbar-brand"><h3> MAFI Coaching </h3></a>
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a href="#" class="nav-link">Home</a>
				</li>
				<li class="nav-item">
					<a href="course.php" class="nav-link">Courses</a>
				</li>
				<li class="nav-item">
					<a href="calender_index.php" class="nav-link">Calender</a>
				</li>
			</ul>

		</div>
		
	</nav>