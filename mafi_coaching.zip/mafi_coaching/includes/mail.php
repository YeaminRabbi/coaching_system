<?php

function email($to,$subject,$message)
	{
				//the subject
			$sub = $subject;
			//the message
			$msg = $message;
			//recipient email here
			$rec = $to;
			//send email
			mail($rec,$sub,$msg);
	}



?>