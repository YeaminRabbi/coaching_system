<nav class="navbar navbar-expand-sm navbar-light bg-light">
		<div class="container">
			<a href="userpage.php" class="navbar navbar-brand"><h3> MAFI Coaching </h3></a>
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a href="userpage.php" class="nav-link">Home</a>
				</li>
				<li class="nav-item">
					<a href="course.php" class="nav-link">Courses</a>
				</li>
				<li class="nav-item">
					<a href="#" class="nav-link">Calender</a>
				</li>
				

				
			</ul>


			<ul class="nav navbar-nav navbar-right">

				
				<?php

					$gap="&nbsp";
				  if(isset($_SESSION['login'])) { ?>
					<li><a href="#"><?php  echo "USER: "; echo  $_SESSION['username']; ?></a></li>	
					<li><a href="#"><?php  echo $gap.$gap.$gap; ?></a></li>	

					<li><a href="#"><?php  echo "ID: "; echo  $_SESSION['id']; ?></a></li>	
				<?php } ?>

				<li class="active" style="padding-left: 20px;"><a href="logout.php"> <button class="btn btn-danger">Logout</button></a></li>
				
				
				
			</ul>

				
		</div>
		
	</nav>