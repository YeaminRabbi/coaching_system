<?php require_once('includes/header.php') ?>
	<!--Navigation Bar-->
	<?php require_once('includes/nav.php') ?>

	<div class="cointainer">
		<div class="row">
			<div class="col-lg-4 m-auto">
				<div class="card bg-light mt-5 py-2">
					<div class="card-title">
						<h2 class="text-center mt-2"> Recover Password </h2>
						<hr>
					</div>
					<div class="card-body">
						<input type="text" name="UEmail" placeholder=" User Email " class="form-control py-2 mb-2">
						
					</div>
					<div class="card-footer">

						<a href="index.php"><button class="btn btn-danger float-right"> Cancel</button></a>
						

						<a href="code.php"><button class="btn btn-dark float-left"> Send Password</button></a>
					</div>

					
				</div>
				
			</div>
			
		</div>
		
	</div>
<?php require_once('includes/footer.php') ?>


	