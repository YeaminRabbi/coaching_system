

<?php require_once('dbconfig.php') ?>


<?php


	
						/////////////////
		if(isset($_POST['submit'])){


$Username= $_POST['USERNAME'];	
$email= $_POST['email'];
$contact= $_POST['contact'];
$pass= $_POST['pass'];
$active=1;
    
     
#$hostname = "localhost";
#$username = "root";
#$password = "";
#$databaseName = "mafi_coaching";

// connect to mysql database

#$connect = mysqli_connect($hostname, $username, $password, $databaseName);

        $query = "INSERT INTO user VALUES ('','$Username','$email','$pass','$active','$contact')";
        $a = mysqli_query($db, $query);








//the subject
$sub = "Registeration";
//the message
$msg = "You are successfully Registered
UserName: $Username
Password: $pass";
//recipient email here
$rec = $email;
//send email
mail($rec,$sub,$msg);
}










echo "<script>location.assign('register.php');</script>";
?>







