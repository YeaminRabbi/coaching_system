<?php

	// Clean String values
	function clean($string)
	{
		return htmlentities($string);
	}

	// redirection
	function redirect($location)
	{
		return header("location:{$location}");
	}


	// set Session message
	function set_message($msg)
	{
		if(!$msg)
		{
			$_SESSION['Message']=$msg;
		}
		else 
		{
			$msg="";
		}
	}


	// display message function
	function display_message()
	{
		echo $_SESSION['Message'];
		unset($_SESSION['Message']);
	}

	// generate token
	function token_generator()
	{
		$token= $_SESSION['token']=md5(uniqid(mt_rand(),true));
		return $token;
	}


	//************* User validation Functions******//

	function user_validation()
	{
		if($_SERVER['REQUEST_METHOD']== 'POST')
		{
			$username = clean($_POST['username']);
			$email = clean($_POST['email']);
			$contact = clean($_POST['contact']);
			$pass = clean($_POST['pass']);
			$cpass = clean($_POST['cpass']);


			$errors=[];

			if(email_exists($email))
			{
				$errors[]=" Email Already Registered !";
			}

			if($pass!=$cpass)
			{
				$errors[]=" Password NOT MATCHED !";
			}


			if(!empty($errors))
			{
				foreach ($errors as $error) {
					echo '<div class ="alert alert-danger">'.$error.'</div>';
				}
			}
		}
	}


	// email exists
	function email_exists($email)
	{
		$sql= " select * from user where email='$email'";
		$result= Query($sql);
		if(fetch_data($result))
		{
			return true;

		}
		else
		{
			return false;
		}
	}

	//


?>