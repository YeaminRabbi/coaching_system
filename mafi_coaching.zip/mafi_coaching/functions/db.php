<?php

	$con = mysqli_connect('localhost', 'root', '', 'mafi_coaching');

	// function CLean String values
	function escape($string)
	{
		global $con;
		return mysqli_real_escape_string($con, $string);
	}
	

	//Query function

	function Query($query)
	{
		global $con;
		return mysqli_query($con,$query);
	}

	// confirmation function

	function confirm($result)
	{
		global $con;
		if(!$result)
		{
			die('Query Failed'.mysqli_error($con));
		}
	}


	// fetch data from database
	function fetch_data($result)
	{
		global $con;
		return mysqli_fetch_assoc($result);
	}


	//row values from database
	function row_count($count)
	{
		return mysqli_num_rows($count);
	}

?>