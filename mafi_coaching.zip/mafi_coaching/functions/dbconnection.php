<?php

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "mafi_coaching";



$connect = mysqli_connect($hostname, $username, $password, $databaseName);


?>