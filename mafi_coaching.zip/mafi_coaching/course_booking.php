<?php require_once('session_check.php') ?>


<?php


            
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $databaseName = "mafi_coaching";


    $connect = mysqli_connect($hostname, $username, $password, $databaseName);

        ##fetching the  course id###
        $sql = "SELECT * FROM events where title='$course'";
        $result = mysqli_query($connect,$sql);
        $row = mysqli_fetch_array($result, MYSQLI_NUM);
       
      

          $course_id=$row[0];
          $course_date=$row[2];
          $course_faculty=$row[4];
          $username=$_SESSION['username'];

          $connect = mysqli_connect($hostname, $username, $password, $databaseName);
          $query="INSERT INTO table_course VALUES('','$code','$course','$student_id','$username','$course_id','')";

           
          $a = mysqli_query($connect, $query);



          #echo "<script>location.assign('userpage.php');</script>";
?>