<?php require_once('dbconfig.php') ?>
<?php require_once('session_check.php') ?>

<?php require_once('includes/header.php') ?>
<?php require_once('includes/admin_nav.php') ?>
<?php require_once('includes/mail.php') ?>


	<div class="container" style="padding-top: 20px;">
		<div style="padding-left: 41%">
			<h3>Registration Table</h3>

			
		</div>
		
			<div style="padding-top: 10px;">
				
				<form action="", method="post">
						<input type="text" name="unique_code" placeholder="--CODE--" >
						<input type="text" name="student_id" placeholder="--STUDENT ID--" >
						
						
						<input type="submit" name="register" value="Register" class="btn btn-dark"  >
				</form>
			</div>

		<table class="table">
    	<thead>
	      <tr>
	        <th>CODE</th>
	        <th>Course Name</th>
	        <th>Student ID</th>
	        <th>Student Name</th>
	        <th>Registered</th>

	        
	        
	      </tr>

	      <?php
	      	$sql = "SELECT unique_code,course_name,student_id,student_name,activation from table_course where activation=0";


			      $result = $db-> query($sql);
			      if($result-> num_rows >0)
			      {


			        while ($row = $result-> fetch_assoc()) {
			            echo "<tr>
			            <td>". $row["unique_code"] ."</td>
			            <td>". $row["course_name"] ."</td>
			            <td>". $row["student_id"] ."</td>
			            <td>". $row["student_name"] ."</td>
			            <td>". $row["activation"] ."</td>
			            
			            </tr>";         
			          }
			            echo "</table>";
			      }

			      
			    



	      ?>






    </thead>



	</div>


 <?php

	

	if(isset($_POST['register']))
	{
		 $code = $_POST['unique_code'];	
		 $student_id = $_POST['student_id'];
		
		$sql = "SELECT * FROM table_course where unique_code='$code'";
        $result = mysqli_query($db,$sql);
        $row = mysqli_fetch_array($result, MYSQLI_NUM);
       
      

          $db_student_id=$row[3];
          $db_code=$row[1];


         # echo $row[1].$row[3];

          if($student_id==$db_student_id)
          {
          	$sql="UPDATE table_course set activation = 1 WHERE unique_code='$code' and student_id='$student_id'";
          	$result = $db-> query($sql);



          }
          else
          {
          	echo "<script>window.alert('DATA ERROR');</script>";
          }



          $sql = "SELECT * FROM user where id='$student_id'";
        	$result = mysqli_query($db,$sql);
        	$row = mysqli_fetch_array($result, MYSQLI_NUM);

        	$email=$row[2];



          email($email,"Registered","You have been Succesfully registered.
          	Check Profile for Update");


          	echo "<script>location.assign('course_registration.php');</script>";


	}


	?>

















<?php require_once('includes/footer.php') ?>