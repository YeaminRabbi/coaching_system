<?php require_once('dbconfig.php') ?>
<?php require_once('session_check.php') ?>
<?php require_once('includes/header.php') ?>
	<!--Navigation Bar-->
	<?php require_once('includes/admin_nav.php') ?>

	


<div class="cointainer">
		<div class="row">
			<div class="col-lg-5 m-auto">
				<div class="card bg-light mt-5 py-2">
					<div class="card-title">
						<h2 class="text-center mt-2"> Course Details </h2>
						<hr>
					</div>
					<div class="card-body">
					
						<form action="" method="POST">
							<input type="text" name="title" placeholder=" Course Name " class="form-control py-2 mb-2" required>

							<input type="date" name="date" placeholder=" Date " class="form-control py-2 mb-2" required>

							<input type="text" name="faculty" placeholder=" Faculty " class="form-control py-2 mb-2" required>
							
							<input type="text" name="seat" placeholder=" No. Seat " class="form-control py-2 mb-2" required>
							

							<input type="submit" name="submit" value="submit" class="btn btn-success float-right" >




							<?php


								if(isset($_POST['submit'])){

									$title= $_POST['title'];	
									$date= $_POST['date'];
									$faculty= $_POST['faculty'];
									$seat= $_POST['seat'];
									$status=1;



									$query = "INSERT INTO events VALUES ('','$title','$date','$status','$faculty','$seat')";
									$a = mysqli_query($db, $query);





								}


							?>


							
						</form>


					</div>
					
				</div>
				
			</div>
			
		</div>
		
	</div>



<?php require_once('includes/footer.php') ?>

